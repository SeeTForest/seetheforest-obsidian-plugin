# SeeTheForest Atlas

SeeTheForest Atlas（见林知识星图）闭源视觉与交互组件。

`@seetheforest/atlas` 是 SeeTheForest Atlas 当前的兼容包标识。

本制品只包含经过压缩的浏览器宿主代码、优化并剥离调试信息的 Rust/Wasm 物理核心、样式和公开类型声明。源码、Source Map、实验页面、测试夹具与内部调参预设均不包含在制品中。

运行基线：ES2020、WebAssembly、Web Worker、WebGL。组件不要求 SharedArrayBuffer，适用于主流桌面与移动浏览器；具体嵌入式 WebView 仍应按发布质量矩阵验证。

授权、分发和升级方式以 SeeTForest 提供的私有渠道说明为准。禁止反编译、逆向工程、再分发或绕过授权机制。
