export type KnowledgeStatus =
  | "question"
  | "hypothesis"
  | "growing"
  | "supported"
  | "disputed"
  | "evergreen"
  | "superseded"
  | "archive";

export type TopicMapRole =
  "start" | "core" | "application" | "contrast" | "question";

export interface TopicMapEntry {
  targetId: string;
  label: string;
  reason: string;
}

export interface TopicMapSection {
  role: TopicMapRole;
  title: string;
  anchor: string;
  entries: TopicMapEntry[];
}

export interface TopicMapProjection {
  version: string;
  rootId: string;
  slug: string;
  title: string;
  sections: TopicMapSection[];
}

export interface GraphNode {
  id: string;
  slug: string;
  title: string;
  domain: string;
  sections?: string[];
  tags: string[];
  mocs: string[];
  featured: boolean;
  isMoc: boolean;
  hasTopicMap: boolean;
  summary: string;
  structuralRole: "moc" | "core" | "bridge" | "regular";
  navigationReasons: string[];
  readingMinutes: number;
  knowledgeStatus?: KnowledgeStatus;
  incomingLinkCount: number;
  outgoingLinkCount: number;
}

export interface GraphEdge {
  id: string;
  source: string;
  target: string;
  kind: "wiki" | "markdown";
  label: string;
  sourceHeading?: string;
  contextText?: string;
  contextAnchor?: string;
  topicMapRootId?: string;
  topicMapRole?: TopicMapRole;
  topicMapOrder?: number;
}

export interface ContentGraph {
  schemaVersion: string;
  nodes: GraphNode[];
  edges: GraphEdge[];
  topicMaps: TopicMapProjection[];
}

export type AtlasLevel = 1 | 2 | 3;

export interface AtlasSelectionOptions {
  level?: AtlasLevel;
  domain?: string;
  focusId?: string;
  query?: string;
  topicMapRootId?: string;
  maxNodes?: number;
  maxEdges?: number;
}

export interface PositionedGraphNode extends GraphNode {
  x: number;
  y: number;
  visualRadius: number;
  collisionRadius: number;
  hitRadius: number;
  score: number;
  distance?: 0 | 1 | 2;
  topicMapRole?: TopicMapRole;
  labelVisible: boolean;
  forestLayer: "canopy" | "understory";
}

export interface AtlasDomain {
  name: string;
  noteCount: number;
  visibleCount: number;
  x: number;
  y: number;
}

export interface AtlasView {
  level: AtlasLevel;
  nodes: PositionedGraphNode[];
  edges: GraphEdge[];
  domains: AtlasDomain[];
  totalNodes: number;
  totalEdges: number;
  eligibleNodes: number;
  focusedNodeId?: string;
  queryMatchId?: string;
  topicMap?: TopicMapProjection;
}

export interface ForestLayoutSeed {
  id: string;
  x: number;
  y: number;
  visualRadius: number;
  collisionRadius: number;
  hitRadius: number;
  score: number;
  labelVisible: boolean;
  forestLayer: "canopy" | "understory";
}

export type LocalDirection =
  "center" | "incoming" | "outgoing" | "both" | "second";

export interface LocalGraphNode extends PositionedGraphNode {
  distance: 0 | 1 | 2;
  direction: LocalDirection;
}

export interface LocalGraphView {
  centerId: string;
  nodes: LocalGraphNode[];
  edges: GraphEdge[];
  firstHopCount: number;
  secondHopCount: number;
}

export interface EvidenceGraphSelection {
  nodeIds: string[];
  relationIds: string[];
  centerId?: string;
}

export declare function selectAtlasView(
  graph: ContentGraph,
  options?: AtlasSelectionOptions,
): AtlasView;

export declare function selectForestAtlasView(
  graph: ContentGraph,
  options?: Omit<AtlasSelectionOptions, "maxNodes" | "maxEdges">,
): AtlasView;

export declare function createForestLayoutSeed(
  nodes: PositionedGraphNode[],
): ForestLayoutSeed[];

export declare function compileForestLayoutSeed(
  view: AtlasView,
): ForestLayoutSeed[];

export declare function createLocalGraphView(
  graph: ContentGraph,
  centerId: string,
  options?: { maxNodes?: number; maxEdges?: number },
): LocalGraphView;

export declare function createEvidenceGraphView(
  graph: ContentGraph,
  selection: EvidenceGraphSelection,
): LocalGraphView;
