import type { JSX } from "solid-js";

import type {
  AtlasView,
  ContentGraph,
  ForestLayoutSeed,
  LocalGraphView,
  GraphNode,
} from "./protected";

export declare const ATLAS_HOST_API_VERSION = 1;

export interface AtlasHost {
  runtimeAssets?: { workerUrl: string; wasmUrl: string };
  /** Default open preserves v1 activation. Select previews without opening;
   * inspector/text links still call openNode. Context menu is unchanged. */
  nodeActivation?: "select" | "open";
  /** Host owns navigation, history and storage. No website state is touched. */
  openNode(node: GraphNode, event: MouseEvent | KeyboardEvent): void;
  nodeHref?(node: GraphNode): string;
  contextMenu?(node: GraphNode, event: MouseEvent): void;
  /** Explicit user presentation groups; does not alter semantic categories. */
  nodeColors?: Readonly<Record<string, string>>;
}

export interface KnowledgeAtlasProps {
  initialView: AtlasView;
  graphUrl?: string;
  graph?: ContentGraph;
  host?: AtlasHost;
  immersive?: boolean;
  /** Opt-in stable reading panel; omitted preserves existing placement. */
  inspectorLayout?: "default" | "reading-start";
  /** Space reserved below the compact portrait panel, in CSS pixels (0–600). */
  inspectorCompactBottomSpace?: number;
  initialDomain?: string;
  layoutSeed?: ForestLayoutSeed[];
}

export interface LocalGraphProps {
  view: LocalGraphView;
  contextKey?: string;
  language?: string;
  labels?: Partial<LocalGraphLabels>;
}

export interface LocalGraphLabels {
  eyebrow: string;
  title: string;
  description: string;
  current: string;
  direct: string;
  extended: string;
  scope: string;
  list: string;
  open: string;
  atlas: string;
  preview: string;
  close: string;
  reason: string;
  reading: string;
  minutes: string;
  incoming: string;
  outgoing: string;
  both: string;
  second: string;
}

export interface EvidenceGraphReference {
  ref: string;
  nodeId: string;
  url: string;
  section?: string;
}

export interface EvidenceGraphProps {
  graph: ContentGraph;
  nodeIds: string[];
  relationIds: string[];
  centerId?: string;
  references: EvidenceGraphReference[];
  contextKey?: string;
}

export declare function KnowledgeAtlas(props: KnowledgeAtlasProps): JSX.Element;
export declare function LocalGraph(props: LocalGraphProps): JSX.Element;
export declare function EvidenceGraph(props: EvidenceGraphProps): JSX.Element;
